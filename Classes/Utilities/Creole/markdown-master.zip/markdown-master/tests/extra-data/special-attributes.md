Header 1            {#header1}
========

## Header 2 ##      {#header2}

## The Site ##    {.main}

## The Site ##    {.main .shine #the-site}

[link](url){#id1 .class}
![img](url){#id2 .class}


[link][linkref] or [linkref]
![img][linkref]

[linkref]: http://url.de/ "optional title" {#id .class}

this is just normal text {.main .shine #the-site}

some { brackets

some } brackets

some { } brackets